E-COMMERCE PRODUCT LISTING - LAB PROJECT

HOW TO OPEN:
1. Download and extract Ecommerce_Lab_Project.zip.
2. Open Visual Studio Code.
3. Click File > Open Folder.
4. Select the extracted Ecommerce_Lab_Project folder.
5. Open index.html.
6. Right-click inside index.html and choose "Open with Live Server" if you have Live Server installed.
   OR open the folder in File Explorer and double-click index.html to view it in your browser.

WHAT IT USES:
- HTML: webpage structure
- CSS: styling
- CSS Grid: product layout
- Media query: responsive mobile layout

NOTE:
The Add to Cart buttons are visual only; they do not implement shopping-cart functionality.
